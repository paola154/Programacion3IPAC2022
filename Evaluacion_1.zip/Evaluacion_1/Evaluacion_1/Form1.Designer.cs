﻿namespace Evaluacion_1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.FechadateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.AñodateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.VentastextBox = new System.Windows.Forms.TextBox();
            this.Ejecutarbutton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.EdadtextBox = new System.Windows.Forms.TextBox();
            this.AñosLabtextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.salariotextBox = new System.Windows.Forms.TextBox();
            this.SueldotextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // FechadateTimePicker
            // 
            this.FechadateTimePicker.Location = new System.Drawing.Point(187, 28);
            this.FechadateTimePicker.Name = "FechadateTimePicker";
            this.FechadateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.FechadateTimePicker.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese fecha de nacimiento:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ingrese fecha de ingreso:";
            // 
            // AñodateTimePicker
            // 
            this.AñodateTimePicker.Location = new System.Drawing.Point(187, 86);
            this.AñodateTimePicker.Name = "AñodateTimePicker";
            this.AñodateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.AñodateTimePicker.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(92, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ventas promedio:";
            // 
            // VentastextBox
            // 
            this.VentastextBox.Location = new System.Drawing.Point(187, 155);
            this.VentastextBox.Name = "VentastextBox";
            this.VentastextBox.Size = new System.Drawing.Size(100, 20);
            this.VentastextBox.TabIndex = 5;
            // 
            // Ejecutarbutton
            // 
            this.Ejecutarbutton.Location = new System.Drawing.Point(337, 155);
            this.Ejecutarbutton.Name = "Ejecutarbutton";
            this.Ejecutarbutton.Size = new System.Drawing.Size(75, 23);
            this.Ejecutarbutton.TabIndex = 6;
            this.Ejecutarbutton.Text = "Ejecutar";
            this.Ejecutarbutton.UseVisualStyleBackColor = true;
            this.Ejecutarbutton.Click += new System.EventHandler(this.Ejecutarbutton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(80, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Edad del empleado:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(97, 247);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Años laborando:";
            // 
            // EdadtextBox
            // 
            this.EdadtextBox.Location = new System.Drawing.Point(187, 210);
            this.EdadtextBox.Name = "EdadtextBox";
            this.EdadtextBox.Size = new System.Drawing.Size(45, 20);
            this.EdadtextBox.TabIndex = 9;
            // 
            // AñosLabtextBox
            // 
            this.AñosLabtextBox.Location = new System.Drawing.Point(187, 240);
            this.AñosLabtextBox.Name = "AñosLabtextBox";
            this.AñosLabtextBox.Size = new System.Drawing.Size(45, 20);
            this.AñosLabtextBox.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(97, 280);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Nuevo Salario:";
            // 
            // salariotextBox
            // 
            this.salariotextBox.Location = new System.Drawing.Point(187, 280);
            this.salariotextBox.Name = "salariotextBox";
            this.salariotextBox.Size = new System.Drawing.Size(100, 20);
            this.salariotextBox.TabIndex = 12;
            // 
            // SueldotextBox
            // 
            this.SueldotextBox.Location = new System.Drawing.Point(187, 129);
            this.SueldotextBox.Name = "SueldotextBox";
            this.SueldotextBox.Size = new System.Drawing.Size(100, 20);
            this.SueldotextBox.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(92, 129);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Sueldo Actual:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 362);
            this.Controls.Add(this.SueldotextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.salariotextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.AñosLabtextBox);
            this.Controls.Add(this.EdadtextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Ejecutarbutton);
            this.Controls.Add(this.VentastextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AñodateTimePicker);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FechadateTimePicker);
            this.Name = "Form1";
            this.Text = "Evaluación 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker FechadateTimePicker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker AñodateTimePicker;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox VentastextBox;
        private System.Windows.Forms.Button Ejecutarbutton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EdadtextBox;
        private System.Windows.Forms.TextBox AñosLabtextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox salariotextBox;
        private System.Windows.Forms.TextBox SueldotextBox;
        private System.Windows.Forms.Label label7;
    }
}

